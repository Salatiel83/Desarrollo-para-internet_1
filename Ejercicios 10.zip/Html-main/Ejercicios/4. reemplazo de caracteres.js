const reemplazarTexto = (oracion, buscar, reemplazar) => {
  const regexBuscar = new RegExp(buscar, "gi");
  return oracion.replace(regexBuscar, reemplazar);
};

const oracion = "Lorem ipsum dolor sit amet, consectetur adipiscing elit";
const buscar = "ipsum";
const reemplazar = "dolor";
console.log(reemplazarTexto(oracion, buscar, reemplazar)); // "Lorem dolor dolor sit amet, consectetur adipiscing elit"
