constValidarCorreo = (correo) = {
    const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regexCorreo.test(correo);
};

const correo1 = "ejemplo@correo.com";
const correo2 = "ejemplo@correo.net.";
const correo3 = "ejemplo@correo.mx";
console.log(validarCorreo(correo1)); // true
console.log(validarCorreo(correo2)); // false
console.log(validarCorreo(correo3)); // false
