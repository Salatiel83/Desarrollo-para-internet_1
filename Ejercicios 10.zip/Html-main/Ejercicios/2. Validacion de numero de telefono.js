constvalidarTelefono = (telefono) = {
  Const regexTelefono = /^[0-9]{10}$/;
  return regexTelefono.test(telefono);
};

const telefono1 = "1234567890";
const telefono2 = "12a4567890";
const telefono3 = "12345678901";
console.log(validarTelefono(telefono1)); // true
console.log(validarTelefono(telefono2)); // false
console.log(validarTelefono(telefono3)); // false
