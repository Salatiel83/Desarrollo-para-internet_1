constcontarPalabra = (frase, palabra) = {
  const, regexPalabra = new RegExp("\\b" + palabra + "\\b", "gi");
  return (frase.match(regexPalabra) || []).length;
};

const frase = "Este es un ejemplo de texto con ejemplo de palabra repetida";
const palabra = "ejemplo";
console.log(contarPalabra(frase, palabra));
