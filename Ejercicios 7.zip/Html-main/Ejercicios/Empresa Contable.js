function suma(num1, num2) {
  return num1 + num2;
}

// Ejemplo de uso
var resultado = suma(2, 3);
console.log(resultado); // Output: 5
