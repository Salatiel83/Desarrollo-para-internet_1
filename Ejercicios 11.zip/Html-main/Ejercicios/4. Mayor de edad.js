<label for="fecha_nacimiento">Fecha de nacimiento:</label>
<input type="date" id="fecha_nacimiento">
<br>
<button onclick="validarEdad()">Validar edad</button>

<script>
function validarEdad() {
  const fechaNacimiento = new Date(document.getElementById("fecha_nacimiento").value);
  const hoy = new Date();
  const edad = hoy.getFullYear() - fechaNacimiento.getFullYear();
  
  fechaNacimiento.setFullYear(hoy.getFullYear());
  
  if (hoy < fechaNacimiento) {
    edad--;
  }
  
  if (edad >= 18) {
    alert("El usuario es mayor de edad");
  } else {
    alert("El usuario no es mayor de edad");
  }
}
</script>
