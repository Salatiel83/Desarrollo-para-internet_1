<form onsubmit="return validarFormulario()">
  <label for="nombre">Nombre:</label>
  <input type="text" id="nombre" name="nombre">
  <br>
  <label for="correo">Correo electrónico:</label>
  <input type="email" id="correo" name="correo">
  <br>
  <input type="submit" value="Enviar">
</form>

<script>
function validarFormulario() {
  const nombre = document.getElementById("nombre");
  const correo = document.getElementById("correo");
  
  if (nombre.value === "") {
    alert("Por favor, ingrese su nombre");
    return false;
  }
  
  if (correo.value === "") {
    alert("Por favor, ingrese su correo electrónico");
    return false;
  }
}
</script>
