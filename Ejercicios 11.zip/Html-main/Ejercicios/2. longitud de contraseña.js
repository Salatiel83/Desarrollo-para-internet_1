<form onsubmit="return validarFormulario()">
  <label for="contrasena">Contraseña:</label>
  <input type="password" id="contrasena" name="contrasena">
  <br>
  <input type="submit" value="Cambiar contraseña">
</form>

<script>
function validarFormulario() {
  const contrasena = document.getElementById("contrasena");
  
  if (contrasena.value.length < 8) {
    alert("La contraseña debe tener al menos 8 caracteres");
    return false;
  }
  
  return true;
}
</script>
