<form onsubmit="return validarFormulario()">
  <label for="nombre">Nombre:</label>
  <input type="text" id="nombre" name="nombre">
  <br>
  <label for="correo">Correo electrónico:</label>
  <input type="text" id="correo" name="correo">
  <br>
  <label for="mensaje">Mensaje:</label>
  <textarea id="mensaje" name="mensaje"></textarea>
  <br>
  <input type="submit" value="Enviar mensaje">
</form>

<script>
function validarFormulario() {
  const correo = document.getElementById("correo");
  const correoRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  if (!correoRegex.test(correo.value)) {
    alert("El correo electrónico no es válido");
    return false;
  }
  
  return true;
}
</script>
